import { useState, useEffect } from 'react';
import { Plus, Search, FileText, Download, Send, X, Check, XCircle, Clock } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Table from '../components/common/Table';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorMessage from '../components/common/ErrorMessage';
import { facturacionService } from '../services/facturacionService';
import { ventasService } from '../services/ventasService';
import toast from 'react-hot-toast';

export default function Facturacion() {
  const [facturas, setFacturas] = useState([]);
  const [ventas, setVentas] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [estadisticas, setEstadisticas] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');

  const [formData, setFormData] = useState({
    venta: '',
    cliente_nombre: '',
    cliente_rfc: '',
    cliente_email: '',
    cliente_codigo_postal: '',
    uso_cfdi: 'G01',
    metodo_pago: '01'
  });

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [facturasData, ventasData, estadisticasData] = await Promise.all([
        facturacionService.getFacturas(),
        ventasService.getVentas(),
        facturacionService.getEstadisticas()
      ]);
      
      setFacturas(Array.isArray(facturasData) ? facturasData : facturasData.results || []);
      setVentas(Array.isArray(ventasData) ? ventasData : ventasData.results || []);
      setEstadisticas(estadisticasData);
    } catch (err) {
      console.error('Error al cargar datos:', err);
      setError(err.response?.data?.error || 'Error al cargar las facturas');
      toast.error('Error al cargar los datos');
    } finally {
      setLoading(false);
    }
  };

  const filteredFacturas = facturas.filter(factura => {
    const matchesSearch = factura.folio_fiscal?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         factura.cliente_nombre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         factura.cliente_rfc?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = !statusFilter || factura.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const validateForm = () => {
    if (!formData.cliente_nombre.trim()) {
      toast.error('El nombre del cliente es requerido');
      return false;
    }

    const rfcPattern = /^([A-ZÑ&]{3,4})\d{6}([A-Z0-9]{3})$/;
    if (!formData.cliente_rfc.trim() || !rfcPattern.test(formData.cliente_rfc)) {
      toast.error('RFC inválido. Formato: XXXX######XXX');
      return false;
    }

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.cliente_email.trim() || !emailPattern.test(formData.cliente_email)) {
      toast.error('Email inválido');
      return false;
    }

    if (!formData.cliente_codigo_postal.trim() || formData.cliente_codigo_postal.length !== 5) {
      toast.error('Código postal inválido (5 dígitos)');
      return false;
    }

    return true;
  };

  const handleCrearFactura = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    try {
      setSubmitting(true);
      
      const nuevaFactura = await facturacionService.createFactura(formData);
      setFacturas([nuevaFactura, ...facturas]);
      setShowModal(false);
      resetForm();
      
      toast.success('Factura creada correctamente');
      
      // Recargar estadísticas
      const nuevasEstadisticas = await facturacionService.getEstadisticas();
      setEstadisticas(nuevasEstadisticas);
    } catch (err) {
      console.error('Error al crear factura:', err);
      toast.error(err.response?.data?.error || 'Error al crear la factura');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTimbrar = async (id) => {
    if (!confirm('¿Deseas timbrar esta factura? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      toast.loading('Timbrando factura...', { id: 'timbrar' });
      
      const resultado = await facturacionService.timbrarFactura(id);
      
      // Actualizar factura en la lista
      setFacturas(facturas.map(f => 
        f.id === id ? { ...f, status: 'timbrada', ...resultado } : f
      ));
      
      toast.success('Factura timbrada exitosamente', { id: 'timbrar' });
      
      // Recargar estadísticas
      const nuevasEstadisticas = await facturacionService.getEstadisticas();
      setEstadisticas(nuevasEstadisticas);
    } catch (err) {
      console.error('Error al timbrar:', err);
      toast.error(err.response?.data?.error || 'Error al timbrar la factura', { id: 'timbrar' });
    }
  };

  const handleCancelar = async (id) => {
    const motivo = prompt('Ingresa el motivo de cancelación:');
    
    if (!motivo || !motivo.trim()) {
      toast.error('El motivo de cancelación es requerido');
      return;
    }

    try {
      toast.loading('Cancelando factura...', { id: 'cancelar' });
      
      await facturacionService.cancelarFactura(id, motivo);
      
      // Actualizar factura en la lista
      setFacturas(facturas.map(f => 
        f.id === id ? { ...f, status: 'cancelada' } : f
      ));
      
      toast.success('Factura cancelada correctamente', { id: 'cancelar' });
      
      // Recargar estadísticas
      const nuevasEstadisticas = await facturacionService.getEstadisticas();
      setEstadisticas(nuevasEstadisticas);
    } catch (err) {
      console.error('Error al cancelar:', err);
      toast.error(err.response?.data?.error || 'Error al cancelar la factura', { id: 'cancelar' });
    }
  };

  const handleDescargarXML = async (id) => {
    try {
      const { xml_url } = await facturacionService.descargarXML(id);
      window.open(xml_url, '_blank');
      toast.success('Descargando XML...');
    } catch (err) {
      toast.error('Error al descargar XML');
    }
  };

  const handleDescargarPDF = async (id) => {
    try {
      const { pdf_url } = await facturacionService.descargarPDF(id);
      window.open(pdf_url, '_blank');
      toast.success('Descargando PDF...');
    } catch (err) {
      toast.error('Error al descargar PDF');
    }
  };

  const resetForm = () => {
    setFormData({
      venta: '',
      cliente_nombre: '',
      cliente_rfc: '',
      cliente_email: '',
      cliente_codigo_postal: '',
      uso_cfdi: 'G01',
      metodo_pago: '01'
    });
  };

  if (loading) {
    return <LoadingSpinner message="Cargando facturas..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onRetry={cargarDatos} />;
  }

  const getStatusBadge = (status) => {
    const badges = {
      borrador: { bg: 'bg-gray-100', text: 'text-gray-800', icon: Clock },
      timbrada: { bg: 'bg-green-100', text: 'text-green-800', icon: Check },
      cancelada: { bg: 'bg-red-100', text: 'text-red-800', icon: XCircle }
    };

    const badge = badges[status] || badges.borrador;
    const Icon = badge.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded-full ${badge.bg} ${badge.text}`}>
        <Icon className="w-3 h-3" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  const columns = [
    { 
      header: 'Folio Fiscal', 
      cell: (row) => (
        <span className="font-mono text-xs text-gray-900">
          {row.folio_fiscal || 'Pendiente'}
        </span>
      )
    },
    { 
      header: 'Fecha', 
      cell: (row) => (
        <span className="text-sm text-gray-600">
          {new Date(row.fecha_creacion).toLocaleDateString('es-MX')}
        </span>
      )
    },
    { 
      header: 'Cliente', 
      cell: (row) => (
        <div>
          <p className="font-medium text-gray-900">{row.cliente_nombre}</p>
          <p className="text-xs text-gray-500">{row.cliente_rfc}</p>
        </div>
      )
    },
    {
      header: 'Total',
      cell: (row) => (
        <span className="font-semibold text-gray-900">
          ${parseFloat(row.total || 0).toFixed(2)}
        </span>
      )
    },
    {
      header: 'Estado',
      cell: (row) => getStatusBadge(row.status)
    },
    {
      header: 'Acciones',
      cell: (row) => (
        <div className="flex gap-1">
          {row.status === 'borrador' && (
            <button
              onClick={() => handleTimbrar(row.id)}
              className="p-1.5 hover:bg-green-50 text-green-600 rounded transition-colors"
              title="Timbrar"
            >
              <Check className="w-4 h-4" />
            </button>
          )}
          {row.status === 'timbrada' && (
            <>
              <button
                onClick={() => handleDescargarXML(row.id)}
                className="p-1.5 hover:bg-blue-50 text-blue-600 rounded transition-colors"
                title="Descargar XML"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDescargarPDF(row.id)}
                className="p-1.5 hover:bg-purple-50 text-purple-600 rounded transition-colors"
                title="Descargar PDF"
              >
                <FileText className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleCancelar(row.id)}
                className="p-1.5 hover:bg-red-50 text-red-600 rounded transition-colors"
                title="Cancelar"
              >
                <XCircle className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Facturación</h1>
          <p className="text-gray-600 mt-1">Gestiona tus CFDI 4.0</p>
        </div>
        <Button icon={Plus} onClick={() => { resetForm(); setShowModal(true); }}>
          Nueva Factura
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Facturas</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {estadisticas?.total_facturas || 0}
              </h3>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-50 text-green-600 rounded-lg">
              <Check className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Timbradas</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {estadisticas?.timbradas || 0}
              </h3>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-gray-50 text-gray-600 rounded-lg">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Borradores</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {estadisticas?.borradores || 0}
              </h3>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-50 text-purple-600 rounded-lg">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Monto Total</p>
              <h3 className="text-2xl font-bold text-gray-900">
                ${(estadisticas?.monto_total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
              </h3>
            </div>
          </div>
        </div>
      </div>

      {/* Filtros y búsqueda */}
      <Card>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar facturas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Todos los estados</option>
            <option value="borrador">Borradores</option>
            <option value="timbrada">Timbradas</option>
            <option value="cancelada">Canceladas</option>
          </select>
        </div>
      </Card>

      {/* Tabla */}
      <Card>
        <Table columns={columns} data={filteredFacturas} />
        {filteredFacturas.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No se encontraron facturas
          </div>
        )}
      </Card>

      {/* Modal Nueva Factura */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <h2 className="text-xl font-semibold text-gray-900">Nueva Factura</h2>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-600"
                disabled={submitting}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCrearFactura} className="p-6 space-y-4">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-yellow-800">
                  <strong>Nota:</strong> Para timbrar facturas, configura tu API de Facturapi en Configuración.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre o Razón Social *
                  </label>
                  <input
                    type="text"
                    value={formData.cliente_nombre}
                    onChange={(e) => setFormData({ ...formData, cliente_nombre: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    RFC *
                  </label>
                  <input
                    type="text"
                    value={formData.cliente_rfc}
                    onChange={(e) => setFormData({ ...formData, cliente_rfc: e.target.value.toUpperCase() })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    maxLength={13}
                    required
                    disabled={submitting}
                    placeholder="XAXX010101000"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    value={formData.cliente_email}
                    onChange={(e) => setFormData({ ...formData, cliente_email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={submitting}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Código Postal *
                  </label>
                  <input
                    type="text"
                    value={formData.cliente_codigo_postal}
                    onChange={(e) => setFormData({ ...formData, cliente_codigo_postal: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    maxLength={5}
                    required
                    disabled={submitting}
                    placeholder="12345"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Uso CFDI *
                  </label>
                  <select
                    value={formData.uso_cfdi}
                    onChange={(e) => setFormData({ ...formData, uso_cfdi: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                    disabled={submitting}
                  >
                    <option value="G01">G01 - Adquisición de mercancías</option>
                    <option value="G03">G03 - Gastos en general</option>
                    <option value="D01">D01 - Honorarios médicos</option>
                    <option value="P01">P01 - Por definir</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Venta Relacionada (Opcional)
                  </label>
                  <select
                    value={formData.venta}
                    onChange={(e) => setFormData({ ...formData, venta: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    disabled={submitting}
                  >
                    <option value="">Sin venta relacionada</option>
                    {ventas.slice(0, 20).map((venta) => (
                      <option key={venta.id} value={venta.id}>
                        {venta.folio} - {venta.cliente_nombre} - ${parseFloat(venta.total).toFixed(2)}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button type="submit" className="flex-1" disabled={submitting}>
                  {submitting ? 'Creando...' : 'Crear Factura'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowModal(false)}
                  disabled={submitting}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}