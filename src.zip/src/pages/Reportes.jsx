import { useState, useEffect } from 'react';
import { BarChart3, Download, Calendar, TrendingUp, DollarSign, Package } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorMessage from '../components/common/ErrorMessage';
import { reportesService } from '../services/reportesService';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line 
} from 'recharts';
import toast from 'react-hot-toast';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4', '#ec4899'];

export default function Reportes() {
  const [ventasGeneral, setVentasGeneral] = useState(null);
  const [productosMasVendidos, setProductosMasVendidos] = useState([]);
  const [categoriasRendimiento, setCategoriasRendimiento] = useState([]);
  const [analisisFinanciero, setAnalisisFinanciero] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [periodo, setPeriodo] = useState('30'); // días

  useEffect(() => {
    cargarDatos();
  }, [periodo]);

  const cargarDatos = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const fechaFin = new Date();
      const fechaInicio = new Date();
      
      if (periodo === '7') {
        fechaInicio.setDate(fechaInicio.getDate() - 7);
      } else if (periodo === '30') {
        fechaInicio.setMonth(fechaInicio.getMonth() - 1);
      } else if (periodo === '90') {
        fechaInicio.setMonth(fechaInicio.getMonth() - 3);
      } else if (periodo === '180') {
        fechaInicio.setMonth(fechaInicio.getMonth() - 6);
      }

      const [ventasData, productosData, categoriasData, financieroData] = await Promise.all([
        reportesService.getVentasGeneral({
          fecha_inicio: fechaInicio.toISOString().split('T')[0],
          fecha_fin: fechaFin.toISOString().split('T')[0]
        }),
        reportesService.getProductosMasVendidos({ dias: parseInt(periodo) }),
        reportesService.getRendimientoCategorias({ dias: parseInt(periodo) }),
        reportesService.getAnalisisFinanciero({ meses: periodo === '180' ? 6 : 3 })
      ]);
      
      setVentasGeneral(ventasData);
      setProductosMasVendidos(Array.isArray(productosData) ? productosData : []);
      setCategoriasRendimiento(Array.isArray(categoriasData) ? categoriasData : []);
      setAnalisisFinanciero(financieroData);
    } catch (err) {
      console.error('Error al cargar reportes:', err);
      setError(err.response?.data?.error || 'Error al cargar los reportes');
      toast.error('Error al cargar los datos');
    } finally {
      setLoading(false);
    }
  };

  const handleExportar = () => {
    toast.promise(
      new Promise((resolve) => setTimeout(resolve, 1500)),
      {
        loading: 'Generando reporte...',
        success: '¡Reporte generado! (funcionalidad en desarrollo)',
        error: 'Error al generar reporte'
      }
    );
  };

  if (loading) {
    return <LoadingSpinner message="Cargando reportes..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onRetry={cargarDatos} />;
  }

  // Transformar datos para las gráficas
  const ventasPorDia = (ventasGeneral?.ventas_por_dia || []).map(v => ({
    fecha: new Date(v.dia).toLocaleDateString('es-MX', { day: '2-digit', month: 'short' }),
    ventas: parseFloat(v.total || 0),
    cantidad: v.cantidad || 0
  }));

  const categoriasPie = categoriasRendimiento
    .filter(cat => parseFloat(cat.ventas_total || 0) > 0)
    .map(cat => ({
      nombre: cat.nombre,
      valor: parseFloat(cat.ventas_total || 0)
    }));

  const ventasMensuales = (analisisFinanciero?.ventas_mensuales || []).map(v => ({
    mes: new Date(v.mes).toLocaleDateString('es-MX', { month: 'short', year: 'numeric' }),
    ingresos: parseFloat(v.ingresos || 0),
    ticket_promedio: parseFloat(v.ticket_promedio || 0),
    num_ventas: v.num_ventas || 0
  }));

  const formatCurrency = (value) => {
    return `$${value.toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-lg">
          <p className="font-semibold text-gray-800 mb-1">{label}</p>
          {payload.map((entry, index) => (
            <p key={index} style={{ color: entry.color }} className="text-sm">
              {entry.name}: {entry.name.includes('$') || entry.name.includes('Venta') || entry.name.includes('Ingreso') 
                ? formatCurrency(entry.value) 
                : entry.value}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reportes</h1>
          <p className="text-gray-600 mt-1">Análisis y estadísticas de tu negocio</p>
        </div>
        <div className="flex gap-3">
          <select
            value={periodo}
            onChange={(e) => setPeriodo(e.target.value)}
            className="px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="7">Últimos 7 días</option>
            <option value="30">Últimos 30 días</option>
            <option value="90">Últimos 3 meses</option>
            <option value="180">Últimos 6 meses</option>
          </select>
          <Button icon={Download} onClick={handleExportar}>
            Exportar
          </Button>
        </div>
      </div>

      {/* Resumen Financiero */}
      <Card title="Resumen Financiero">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
            <div className="flex items-center justify-center mb-2">
              <DollarSign className="w-6 h-6 text-blue-600 mr-2" />
              <p className="text-sm text-blue-600 font-medium">Ingresos Totales</p>
            </div>
            <h3 className="text-3xl font-bold text-blue-900">
              {formatCurrency(ventasGeneral?.estadisticas?.monto_total || 0)}
            </h3>
            <p className="text-sm text-blue-700 mt-2">
              {ventasGeneral?.estadisticas?.total_ventas || 0} transacciones
            </p>
          </div>
          <div className="text-center p-6 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
            <div className="flex items-center justify-center mb-2">
              <TrendingUp className="w-6 h-6 text-green-600 mr-2" />
              <p className="text-sm text-green-600 font-medium">Utilidad Total</p>
            </div>
            <h3 className="text-3xl font-bold text-green-900">
              {formatCurrency(ventasGeneral?.estadisticas?.total_utilidad || 0)}
            </h3>
            <p className="text-sm text-green-700 mt-2">
              Margen promedio: {ventasGeneral?.estadisticas?.monto_total > 0 
                ? ((ventasGeneral?.estadisticas?.total_utilidad / ventasGeneral?.estadisticas?.monto_total) * 100).toFixed(1)
                : 0}%
            </p>
          </div>
          <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
            <div className="flex items-center justify-center mb-2">
              <Package className="w-6 h-6 text-purple-600 mr-2" />
              <p className="text-sm text-purple-600 font-medium">Ticket Promedio</p>
            </div>
            <h3 className="text-3xl font-bold text-purple-900">
              {formatCurrency(ventasGeneral?.estadisticas?.ticket_promedio || 0)}
            </h3>
            <p className="text-sm text-purple-700 mt-2">Por transacción</p>
          </div>
        </div>
      </Card>

      {/* Gráficas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Ventas Diarias */}
        <Card title="Ventas Diarias">
          {ventasPorDia.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={ventasPorDia}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="fecha" 
                  stroke="#6b7280"
                  style={{ fontSize: '12px' }}
                />
                <YAxis 
                  stroke="#6b7280"
                  style={{ fontSize: '12px' }}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="ventas" fill="#3b82f6" name="Ventas ($)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-gray-500">
              No hay datos disponibles
            </div>
          )}
        </Card>

        {/* Ventas por Categoría */}
        <Card title="Ventas por Categoría">
          {categoriasPie.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoriasPie}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ nombre, percent }) => `${nombre}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="valor"
                >
                  {categoriasPie.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => formatCurrency(value)} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-gray-500">
              No hay datos disponibles
            </div>
          )}
        </Card>
      </div>

      {/* Tendencia Mensual */}
      {ventasMensuales.length > 0 && (
        <Card title="Tendencia de Ingresos Mensuales">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={ventasMensuales}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis 
                dataKey="mes" 
                stroke="#6b7280"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="#6b7280"
                style={{ fontSize: '12px' }}
                tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="ingresos" 
                stroke="#3b82f6" 
                strokeWidth={3}
                name="Ingresos ($)"
                dot={{ fill: '#3b82f6', r: 5 }}
                activeDot={{ r: 7 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Productos Más Vendidos */}
      <Card title="Productos Más Vendidos">
        {productosMasVendidos.length > 0 ? (
          <div className="space-y-3">
            {productosMasVendidos.slice(0, 10).map((item, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center gap-3 flex-1">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-semibold text-sm ${
                    index === 0 ? 'bg-yellow-100 text-yellow-700' :
                    index === 1 ? 'bg-gray-100 text-gray-700' :
                    index === 2 ? 'bg-orange-100 text-orange-700' :
                    'bg-blue-50 text-blue-600'
                  }`}>
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">
                      {item.producto__nombre || 'Producto'}
                    </p>
                    <div className="flex items-center gap-4 mt-1">
                      <p className="text-sm text-gray-500">
                        {item.cantidad_vendida} unidades
                      </p>
                      <p className="text-sm text-gray-500">
                        {item.num_ventas} ventas
                      </p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-gray-900">
                    {formatCurrency(parseFloat(item.total_vendido || 0))}
                  </p>
                  <p className="text-sm text-green-600 font-medium">
                    Utilidad: {formatCurrency(parseFloat(item.utilidad_total || 0))}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            No hay datos disponibles
          </div>
        )}
      </Card>

      {/* Rendimiento por Categorías */}
      {categoriasRendimiento.length > 0 && (
        <Card title="Rendimiento por Categorías">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Categoría</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Ventas</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Cantidad</th>
                  <th className="text-right py-3 px-4 font-semibold text-gray-700">Utilidad</th>
                </tr>
              </thead>
              <tbody>
                {categoriasRendimiento.map((cat, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <span className="font-medium text-gray-800">{cat.nombre}</span>
                    </td>
                    <td className="py-3 px-4 text-right font-semibold text-gray-900">
                      {formatCurrency(parseFloat(cat.ventas_total || 0))}
                    </td>
                    <td className="py-3 px-4 text-right text-gray-600">
                      {cat.cantidad_vendida || 0} unidades
                    </td>
                    <td className="py-3 px-4 text-right font-medium text-green-600">
                      {formatCurrency(parseFloat(cat.utilidad_total || 0))}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Métodos de Pago */}
      {ventasGeneral?.por_metodo_pago && ventasGeneral.por_metodo_pago.length > 0 && (
        <Card title="Distribución por Método de Pago">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {ventasGeneral.por_metodo_pago.map((metodo, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 capitalize mb-1">{metodo.metodo_pago}</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(parseFloat(metodo.total || 0))}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  {metodo.cantidad} transacciones
                </p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}