import { useState, useEffect } from 'react';
import { Plus, Search, Calendar, DollarSign, ShoppingBag, TrendingUp, X, Minus, AlertCircle } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Table from '../components/common/Table';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorMessage from '../components/common/ErrorMessage';
import { ventasService } from '../services/ventasService';
import { inventarioService } from '../services/inventarioService';
import toast from 'react-hot-toast';

export default function Ventas() {
  const [sales, setSales] = useState([]);
  const [productos, setProductos] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [estadisticas, setEstadisticas] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  
  // Estados del carrito de venta
  const [carrito, setCarrito] = useState([]);
  const [clienteNombre, setClienteNombre] = useState('Público General');
  const [clienteRfc, setClienteRfc] = useState('');
  const [metodoPago, setMetodoPago] = useState('efectivo');
  const [buscarProducto, setBuscarProducto] = useState('');
  const [observaciones, setObservaciones] = useState('');

  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [ventasData, productosData, estadisticasData] = await Promise.all([
        ventasService.getVentas(),
        inventarioService.getProductos(),
        ventasService.getEstadisticasHoy()
      ]);
      
      setSales(Array.isArray(ventasData) ? ventasData : ventasData.results || []);
      setProductos(Array.isArray(productosData) ? productosData : productosData.results || []);
      setEstadisticas(estadisticasData);
    } catch (err) {
      console.error('Error al cargar datos:', err);
      setError(err.response?.data?.error || 'Error al cargar las ventas');
      toast.error('Error al cargar los datos');
    } finally {
      setLoading(false);
    }
  };

  const filteredSales = sales.filter(sale =>
    sale.folio?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sale.cliente_nombre?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const productosFiltrados = productos.filter(p =>
    (p.nombre?.toLowerCase().includes(buscarProducto.toLowerCase()) ||
    p.codigo?.toLowerCase().includes(buscarProducto.toLowerCase())) &&
    p.stock > 0 // Solo mostrar productos con stock
  );

  const agregarAlCarrito = (producto) => {
    const itemExistente = carrito.find(item => item.producto.id === producto.id);
    
    if (itemExistente) {
      if (itemExistente.cantidad < producto.stock) {
        setCarrito(carrito.map(item =>
          item.producto.id === producto.id
            ? { ...item, cantidad: item.cantidad + 1 }
            : item
        ));
        toast.success(`Cantidad actualizada: ${producto.nombre}`);
      } else {
        toast.error('No hay suficiente stock disponible');
      }
    } else {
      if (producto.stock > 0) {
        setCarrito([...carrito, {
          producto: producto,
          cantidad: 1,
          precio_unitario: parseFloat(producto.precio_venta)
        }]);
        toast.success(`Agregado al carrito: ${producto.nombre}`);
      } else {
        toast.error('Producto sin stock');
      }
    }
  };

  const eliminarDelCarrito = (productoId) => {
    const producto = carrito.find(item => item.producto.id === productoId);
    setCarrito(carrito.filter(item => item.producto.id !== productoId));
    toast.success(`Eliminado: ${producto.producto.nombre}`);
  };

  const actualizarCantidad = (productoId, nuevaCantidad) => {
    const item = carrito.find(i => i.producto.id === productoId);
    
    if (nuevaCantidad <= 0) {
      eliminarDelCarrito(productoId);
      return;
    }
    
    if (nuevaCantidad > item.producto.stock) {
      toast.error(`Stock máximo disponible: ${item.producto.stock}`);
      return;
    }
    
    setCarrito(carrito.map(item =>
      item.producto.id === productoId
        ? { ...item, cantidad: nuevaCantidad }
        : item
    ));
  };

  const calcularSubtotal = () => {
    return carrito.reduce((sum, item) => sum + (item.cantidad * item.precio_unitario), 0);
  };

  const calcularIVA = () => {
    return calcularSubtotal() * 0.16;
  };

  const calcularTotal = () => {
    return calcularSubtotal() + calcularIVA();
  };

  const validarVenta = () => {
    if (carrito.length === 0) {
      toast.error('Agrega productos al carrito');
      return false;
    }

    if (!clienteNombre.trim()) {
      toast.error('Ingresa el nombre del cliente');
      return false;
    }

    // Validar RFC si se proporcionó
    if (clienteRfc && clienteRfc.trim()) {
      const rfcPattern = /^([A-ZÑ&]{3,4})\d{6}([A-Z0-9]{3})$/;
      if (!rfcPattern.test(clienteRfc.toUpperCase())) {
        toast.error('RFC inválido. Formato: XXXX######XXX');
        return false;
      }
    }

    return true;
  };

  const handleCompletarVenta = async () => {
    if (!validarVenta()) return;

    try {
      setSubmitting(true);
      
      const ventaData = {
        cliente_nombre: clienteNombre.trim(),
        cliente_rfc: clienteRfc?.trim() || null,
        metodo_pago: metodoPago,
        observaciones: observaciones.trim(),
        detalles: carrito.map(item => ({
          producto: item.producto.id,
          cantidad: item.cantidad,
          precio_unitario: item.precio_unitario
        }))
      };

      const nuevaVenta = await ventasService.createVenta(ventaData);
      
      // Agregar la nueva venta al inicio de la lista
      setSales([nuevaVenta, ...sales]);
      
      // Actualizar productos en el estado local
      setProductos(productos.map(p => {
        const itemVendido = carrito.find(item => item.producto.id === p.id);
        if (itemVendido) {
          return { ...p, stock: p.stock - itemVendido.cantidad };
        }
        return p;
      }));
      
      // Limpiar formulario
      limpiarFormulario();
      setShowModal(false);
      
      // Recargar estadísticas
      const nuevasEstadisticas = await ventasService.getEstadisticasHoy();
      setEstadisticas(nuevasEstadisticas);
      
      toast.success(`¡Venta ${nuevaVenta.folio} completada exitosamente!`, {
        duration: 4000,
        icon: '🎉',
      });
    } catch (err) {
      console.error('Error al crear venta:', err);
      const errorMsg = err.response?.data?.error || 
                      err.response?.data?.detail ||
                      'Error al completar la venta';
      toast.error(errorMsg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelarVenta = async (ventaId) => {
    if (!confirm('¿Estás seguro de cancelar esta venta? Esta acción no se puede deshacer.')) {
      return;
    }

    try {
      await ventasService.cancelarVenta(ventaId);
      
      // Actualizar la lista
      setSales(sales.map(v => 
        v.id === ventaId ? { ...v, cancelada: true } : v
      ));
      
      // Recargar datos para actualizar stock
      await cargarDatos();
      
      toast.success('Venta cancelada correctamente');
    } catch (err) {
      console.error('Error al cancelar venta:', err);
      toast.error(err.response?.data?.error || 'Error al cancelar la venta');
    }
  };

  const limpiarFormulario = () => {
    setCarrito([]);
    setClienteNombre('Público General');
    setClienteRfc('');
    setMetodoPago('efectivo');
    setObservaciones('');
    setBuscarProducto('');
  };

  if (loading) {
    return <LoadingSpinner message="Cargando ventas..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onRetry={cargarDatos} />;
  }

  const columns = [
    { 
      header: 'Folio', 
      accessor: 'folio',
      cell: (row) => (
        <span className="font-mono font-semibold text-gray-900">
          {row.folio}
        </span>
      )
    },
    { 
      header: 'Fecha', 
      cell: (row) => (
        <div>
          <div className="font-medium text-gray-900">
            {new Date(row.fecha).toLocaleDateString('es-MX', { 
              day: '2-digit', 
              month: 'short',
              year: 'numeric'
            })}
          </div>
          <div className="text-xs text-gray-500">
            {new Date(row.fecha).toLocaleTimeString('es-MX', { 
              hour: '2-digit',
              minute: '2-digit'
            })}
          </div>
        </div>
      )
    },
    { 
      header: 'Cliente', 
      accessor: 'cliente_nombre',
      cell: (row) => (
        <div>
          <div className="font-medium text-gray-900">{row.cliente_nombre}</div>
          {row.cliente_rfc && (
            <div className="text-xs text-gray-500">{row.cliente_rfc}</div>
          )}
        </div>
      )
    },
    {
      header: 'Total',
      cell: (row) => (
        <span className="font-semibold text-green-600">
          ${parseFloat(row.total).toLocaleString('es-MX', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
      )
    },
    { 
      header: 'Método', 
      cell: (row) => (
        <span className="capitalize px-2 py-1 bg-blue-50 text-blue-700 text-xs font-medium rounded">
          {row.metodo_pago}
        </span>
      )
    },
    {
      header: 'Estado',
      cell: (row) => (
        <span className={`px-2 py-1 text-xs font-medium rounded ${
          row.cancelada 
            ? 'bg-red-100 text-red-800' 
            : 'bg-green-100 text-green-800'
        }`}>
          {row.cancelada ? 'Cancelada' : 'Completada'}
        </span>
      )
    },
    {
      header: 'Acciones',
      cell: (row) => (
        <div className="flex gap-2">
          {!row.cancelada && (
            <button
              onClick={() => handleCancelarVenta(row.id)}
              className="px-3 py-1 text-xs font-medium text-red-600 hover:bg-red-50 rounded transition-colors"
            >
              Cancelar
            </button>
          )}
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Ventas</h1>
          <p className="text-gray-600 mt-1">Gestiona las ventas de tu negocio</p>
        </div>
        <Button 
          icon={Plus} 
          onClick={() => {
            limpiarFormulario();
            setShowModal(true);
          }}
        >
          Nueva Venta
        </Button>
      </div>

      {/* Estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
              <ShoppingBag className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Ventas Hoy</p>
              <h3 className="text-2xl font-bold text-gray-900">
                {estadisticas?.total_ventas || 0}
              </h3>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-green-50 text-green-600 rounded-lg">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Hoy</p>
              <h3 className="text-2xl font-bold text-gray-900">
                ${(estadisticas?.monto_total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
              </h3>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-purple-50 text-purple-600 rounded-lg">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Ticket Promedio</p>
              <h3 className="text-2xl font-bold text-gray-900">
                ${(estadisticas?.ticket_promedio || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 })}
              </h3>
            </div>
          </div>
        </div>
      </div>

      {/* Tabla de ventas */}
      <Card>
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Buscar por folio o cliente..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <Table columns={columns} data={filteredSales} />
        {filteredSales.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No se encontraron ventas
          </div>
        )}
      </Card>

      {/* Modal de Nueva Venta */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full max-h-[90vh] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <h2 className="text-xl font-semibold text-gray-900">Nueva Venta</h2>
              <button
                onClick={() => {
                  if (carrito.length > 0) {
                    if (confirm('¿Descartar venta actual?')) {
                      setShowModal(false);
                      limpiarFormulario();
                    }
                  } else {
                    setShowModal(false);
                  }
                }}
                className="text-gray-400 hover:text-gray-600"
                disabled={submitting}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Side - Product Selection */}
                <div className="flex flex-col">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Agregar Productos
                  </h3>
                  
                  <div className="mb-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Buscar producto por nombre o código..."
                        value={buscarProducto}
                        onChange={(e) => setBuscarProducto(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        autoFocus
                      />
                    </div>
                  </div>

                  <div className="space-y-2 overflow-y-auto flex-1 max-h-96">
                    {productosFiltrados.length > 0 ? (
                      productosFiltrados.map((producto) => (
                        <div
                          key={producto.id}
                          className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                          onClick={() => agregarAlCarrito(producto)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="font-medium text-gray-800">{producto.nombre}</p>
                              <p className="text-sm text-gray-500">
                                Código: {producto.codigo} | Stock: <span className={producto.stock <= producto.stock_minimo ? 'text-red-600 font-semibold' : ''}>{producto.stock}</span>
                              </p>
                            </div>
                            <div className="text-right ml-4">
                              <p className="font-semibold text-gray-900 text-lg">
                                ${parseFloat(producto.precio_venta).toFixed(2)}
                              </p>
                              <button className="text-xs text-blue-600 hover:text-blue-700 font-medium">
                                + Agregar
                              </button>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        {buscarProducto ? 'No se encontraron productos' : 'Busca un producto para agregar'}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Side - Cart */}
                <div className="flex flex-col">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">
                    Resumen de Venta
                  </h3>

                  {/* Información del cliente */}
                  <div className="mb-4 space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Cliente *
                      </label>
                      <input
                        type="text"
                        placeholder="Nombre del cliente"
                        value={clienteNombre}
                        onChange={(e) => setClienteNombre(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        disabled={submitting}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        RFC (opcional)
                      </label>
                      <input
                        type="text"
                        placeholder="Ej: XAXX010101000"
                        value={clienteRfc}
                        onChange={(e) => setClienteRfc(e.target.value.toUpperCase())}
                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        maxLength={13}
                        disabled={submitting}
                      />
                    </div>
                  </div>

                  {/* Carrito */}
                  <div className="border border-gray-200 rounded-lg p-4 mb-4 overflow-y-auto flex-1 max-h-64">
                    {carrito.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full text-center py-8">
                        <ShoppingBag className="w-12 h-12 text-gray-300 mb-2" />
                        <p className="text-sm text-gray-500">
                          No hay productos agregados
                        </p>
                        <p className="text-xs text-gray-400 mt-1">
                          Selecciona productos de la lista
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {carrito.map((item) => (
                          <div key={item.producto.id} className="flex items-start gap-3 pb-3 border-b border-gray-100 last:border-0">
                            <div className="flex-1 min-w-0">
                              <p className="font-medium text-sm text-gray-800 truncate">
                                {item.producto.nombre}
                              </p>
                              <p className="text-xs text-gray-500">
                                ${item.precio_unitario.toFixed(2)} c/u
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => actualizarCantidad(item.producto.id, item.cantidad - 1)}
                                className="w-7 h-7 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded transition-colors"
                                disabled={submitting}
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <input
                                type="number"
                                value={item.cantidad}
                                onChange={(e) => actualizarCantidad(item.producto.id, parseInt(e.target.value) || 0)}
                                className="w-12 text-center font-medium border border-gray-200 rounded px-1 py-1 text-sm"
                                min="1"
                                max={item.producto.stock}
                                disabled={submitting}
                              />
                              <button
                                onClick={() => actualizarCantidad(item.producto.id, item.cantidad + 1)}
                                className="w-7 h-7 flex items-center justify-center bg-gray-100 hover:bg-gray-200 rounded transition-colors"
                                disabled={submitting}
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => eliminarDelCarrito(item.producto.id)}
                                className="ml-1 p-1 text-red-600 hover:bg-red-50 rounded transition-colors"
                                disabled={submitting}
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                            <div className="text-right min-w-[80px]">
                              <p className="font-semibold text-gray-900">
                                ${(item.cantidad * item.precio_unitario).toFixed(2)}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Totales */}
                  <div className="space-y-2 mb-4 bg-gray-50 rounded-lg p-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Subtotal:</span>
                      <span className="font-medium">${calcularSubtotal().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">IVA (16%):</span>
                      <span className="font-medium">${calcularIVA().toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-lg font-bold pt-2 border-t border-gray-200">
                      <span>Total:</span>
                      <span className="text-green-600">${calcularTotal().toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Método de pago */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Método de Pago *
                    </label>
                    <select 
                      value={metodoPago}
                      onChange={(e) => setMetodoPago(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      disabled={submitting}
                    >
                      <option value="efectivo">Efectivo</option>
                      <option value="tarjeta">Tarjeta</option>
                      <option value="transferencia">Transferencia</option>
                    </select>
                  </div>

                  {/* Observaciones */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Observaciones (opcional)
                    </label>
                    <textarea
                      value={observaciones}
                      onChange={(e) => setObservaciones(e.target.value)}
                      placeholder="Notas adicionales..."
                      rows="2"
                      className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                      disabled={submitting}
                    />
                  </div>

                  {/* Botones */}
                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <Button 
                      className="flex-1"
                      onClick={handleCompletarVenta}
                      disabled={carrito.length === 0 || submitting}
                    >
                      {submitting ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                          Procesando...
                        </>
                      ) : (
                        <>Completar Venta</>
                      )}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        if (carrito.length > 0) {
                          if (confirm('¿Descartar venta actual?')) {
                            setShowModal(false);
                            limpiarFormulario();
                          }
                        } else {
                          setShowModal(false);
                        }
                      }}
                      disabled={submitting}
                    >
                      Cancelar
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}