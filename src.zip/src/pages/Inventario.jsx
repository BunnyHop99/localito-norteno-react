import { useState, useEffect } from 'react';
import { Plus, Search, Filter, Edit, Trash2, Package, AlertCircle, TrendingUp, TrendingDown } from 'lucide-react';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Table from '../components/common/Table';
import LoadingSpinner from '../components/common/LoadingSpinner';
import ErrorMessage from '../components/common/ErrorMessage';
import { inventarioService } from '../services/inventarioService';
import toast from 'react-hot-toast';

export default function Inventario() {
    const [products, setProducts] = useState([]);
    const [categorias, setCategorias] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [categoriaFiltro, setCategoriaFiltro] = useState('');
    const [stockFiltro, setStockFiltro] = useState('todos');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [showCategoriaModal, setShowCategoriaModal] = useState(false);
    const [selectedProduct, setSelectedProduct] = useState(null);
    const [submitting, setSubmitting] = useState(false);

    const [formData, setFormData] = useState({
        codigo: '',
        nombre: '',
        descripcion: '',
        categoria: '',
        stock: '',
        stock_minimo: '',
        precio_venta: '',
        precio_costo: ''
    });

    const [nuevaCategoria, setNuevaCategoria] = useState({
        nombre: '',
        descripcion: ''
    });

    useEffect(() => {
        cargarDatos();
    }, []);

    const cargarDatos = async () => {
        try {
            setLoading(true);
            setError(null);

            const [productosData, categoriasData] = await Promise.all([
                inventarioService.getProductos(),
                inventarioService.getCategorias()
            ]);

            setProducts(Array.isArray(productosData) ? productosData : productosData.results || []);
            setCategorias(Array.isArray(categoriasData) ? categoriasData : categoriasData.results || []);
        } catch (err) {
            console.error('Error al cargar datos:', err);
            setError(err.response?.data?.error || 'Error al cargar los productos');
            toast.error('Error al cargar los datos');
        } finally {
            setLoading(false);
        }
    };

    const filteredProducts = products.filter(product => {
        const matchesSearch = product.nombre?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            product.codigo?.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesCategoria = !categoriaFiltro || product.categoria === parseInt(categoriaFiltro);

        const matchesStock = stockFiltro === 'todos' ||
            (stockFiltro === 'bajo' && product.stock_bajo) ||
            (stockFiltro === 'sin_stock' && product.stock === 0);

        return matchesSearch && matchesCategoria && matchesStock;
    });

    const validateProductForm = () => {
        // Validación de código
        if (!formData.codigo.trim()) {
            toast.error('El código es requerido');
            return false;
        }

        // 🆕 NUEVO: Verificar si el código ya existe (solo al crear, no al editar)
        if (!selectedProduct) {
            const codigoExiste = products.find(
                p => p.codigo.toLowerCase() === formData.codigo.trim().toLowerCase()
            );

            if (codigoExiste) {
                toast.error(`Ya existe un producto con el código "${formData.codigo}"`);
                // Opcional: resaltar el campo
                return false;
            }
        }

        // Validación de nombre
        if (!formData.nombre.trim()) {
            toast.error('El nombre es requerido');
            return false;
        }

        // Validación de categoría
        if (!formData.categoria) {
            toast.error('Selecciona una categoría');
            return false;
        }

        // Validación de stock
        if (formData.stock === '' || formData.stock < 0) {
            toast.error('El stock debe ser mayor o igual a 0');
            return false;
        }

        // Validación de stock mínimo
        if (formData.stock_minimo === '' || formData.stock_minimo < 0) {
            toast.error('El stock mínimo debe ser mayor o igual a 0');
            return false;
        }

        // Validación de precio costo
        if (!formData.precio_costo || parseFloat(formData.precio_costo) <= 0) {
            toast.error('El precio de costo debe ser mayor a 0');
            return false;
        }

        // Validación de precio venta
        if (!formData.precio_venta || parseFloat(formData.precio_venta) <= 0) {
            toast.error('El precio de venta debe ser mayor a 0');
            return false;
        }

        // Advertencia si precio venta < costo
        if (parseFloat(formData.precio_venta) < parseFloat(formData.precio_costo)) {
            if (!confirm('El precio de venta es menor que el costo. ¿Continuar?')) {
                return false;
            }
        }

        return true;
    };

    const handleEdit = (product) => {
        setSelectedProduct(product);
        setFormData({
            codigo: product.codigo,
            nombre: product.nombre,
            descripcion: product.descripcion || '',
            categoria: product.categoria,
            stock: product.stock,
            stock_minimo: product.stock_minimo,
            precio_venta: product.precio_venta,
            precio_costo: product.precio_costo
        });
        setShowModal(true);
    };

    const handleDelete = async (id) => {
        const producto = products.find(p => p.id === id);
        if (!confirm(`¿Estás seguro de eliminar "${producto.nombre}"?`)) return;

        try {
            await inventarioService.deleteProducto(id);
            setProducts(products.filter(p => p.id !== id));
            toast.success('Producto eliminado correctamente');
        } catch (err) {
            console.error('Error al eliminar producto:', err);
            toast.error(err.response?.data?.error || 'Error al eliminar el producto');
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateProductForm()) return;

        try {
            setSubmitting(true);

            // Preparar datos asegurando tipos correctos
            const dataToSend = {
                codigo: formData.codigo.trim(),
                nombre: formData.nombre.trim(),
                descripcion: formData.descripcion?.trim() || '',
                categoria: parseInt(formData.categoria),
                stock: parseInt(formData.stock) || 0,
                stock_minimo: parseInt(formData.stock_minimo) || 0,
                precio_venta: parseFloat(formData.precio_venta),
                precio_costo: parseFloat(formData.precio_costo)
            };

            console.log('Enviando datos:', dataToSend);
            console.log("Tipos de datos:", {
                categoria: typeof dataToSend.categoria,
                stock: typeof dataToSend.stock,
                precio_venta: typeof dataToSend.precio_venta
            });
            console.log("FormData original:", formData);

            if (selectedProduct) {
                const updated = await inventarioService.updateProducto(selectedProduct.id, dataToSend);
                setProducts(products.map(p => p.id === selectedProduct.id ? updated : p));
                toast.success('Producto actualizado correctamente');
            } else {
                const created = await inventarioService.createProducto(dataToSend);
                setProducts([created, ...products]);
                toast.success('Producto creado correctamente');
            }

            setShowModal(false);
            setSelectedProduct(null);
            resetForm();
        } catch (err) {
            console.error('Error completo:', err);

            // Si es un APIError, acceder a err.data
            // Si no, acceder a err.response?.data
            const errorData = err.data || err.response?.data || null;
            const originalError = err.originalError || err;

            console.error('Error data:', errorData);
            console.error('Original error:', originalError.response?.data);

            // Mostrar errores de validación específicos
            if (errorData) {
                // Si hay errores de campo específicos (formato Django REST)
                if (typeof errorData === 'object' && !errorData.error && !errorData.detail && !errorData.message) {
                    const errorMessages = [];
                    for (const [field, messages] of Object.entries(errorData)) {
                        const message = Array.isArray(messages) ? messages.join(', ') : messages;
                        errorMessages.push(`${field}: ${message}`);
                    }
                    if (errorMessages.length > 0) {
                        console.error('Errores de campo:', errorMessages);
                        toast.error(errorMessages.join('\n'));
                        return;
                    }
                }

                // Error general
                const errorMsg = errorData.error || errorData.detail || errorData.message || 'Error al guardar el producto';
                toast.error(errorMsg);
            } else {
                // Si no hay datos de error, usar el mensaje del error
                toast.error(err.message || 'Error de conexión al guardar el producto');
            }
        } finally {
            setSubmitting(false);
        }
    };

    const handleCrearCategoria = async (e) => {
        e.preventDefault();

        if (!nuevaCategoria.nombre.trim()) {
            toast.error('El nombre de la categoría es requerido');
            return;
        }

        try {
            setSubmitting(true);
            const created = await inventarioService.createCategoria(nuevaCategoria);
            setCategorias([...categorias, created]);
            setShowCategoriaModal(false);
            setNuevaCategoria({ nombre: '', descripcion: '' });
            toast.success('Categoría creada correctamente');
        } catch (err) {
            console.error('Error al crear categoría:', err);
            toast.error(err.response?.data?.error || 'Error al crear la categoría');
        } finally {
            setSubmitting(false);
        }
    };

    const resetForm = () => {
        setFormData({
            codigo: '',
            nombre: '',
            descripcion: '',
            categoria: '',
            stock: '',
            stock_minimo: '',
            precio_venta: '',
            precio_costo: ''
        });
    };

    if (loading) {
        return <LoadingSpinner message="Cargando inventario..." />;
    }

    if (error) {
        return <ErrorMessage message={error} onRetry={cargarDatos} />;
    }

    const columns = [
        {
            header: 'Código',
            accessor: 'codigo',
            cell: (row) => (
                <span className="font-mono text-sm text-gray-900">{row.codigo}</span>
            )
        },
        {
            header: 'Producto',
            cell: (row) => (
                <div>
                    <p className="font-medium text-gray-900">{row.nombre}</p>
                    {row.descripcion && (
                        <p className="text-xs text-gray-500 truncate max-w-xs">{row.descripcion}</p>
                    )}
                </div>
            )
        },
        {
            header: 'Categoría',
            cell: (row) => (
                <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded">
                    {row.categoria_nombre || 'Sin categoría'}
                </span>
            )
        },
        {
            header: 'Stock',
            cell: (row) => (
                <div className="flex items-center gap-2">
                    <span className={`font-semibold ${row.stock === 0 ? 'text-red-600' :
                            row.stock_bajo ? 'text-orange-600' :
                                'text-green-600'
                        }`}>
                        {row.stock}
                    </span>
                    {row.stock_bajo && row.stock > 0 && (
                        <div className="flex items-center gap-1 text-orange-600" title="Stock bajo">
                            <TrendingDown className="w-4 h-4" />
                            <span className="text-xs">(Mín: {row.stock_minimo})</span>
                        </div>
                    )}
                    {row.stock === 0 && (
                        <AlertCircle className="w-4 h-4 text-red-500" title="Sin stock" />
                    )}
                </div>
            )
        },
        {
            header: 'Precio Costo',
            cell: (row) => (
                <span className="text-sm text-gray-600">
                    ${parseFloat(row.precio_costo).toFixed(2)}
                </span>
            )
        },
        {
            header: 'Precio Venta',
            cell: (row) => (
                <span className="font-semibold text-green-600">
                    ${parseFloat(row.precio_venta).toFixed(2)}
                </span>
            )
        },
        {
            header: 'Margen',
            cell: (row) => {
                const margen = ((parseFloat(row.precio_venta) - parseFloat(row.precio_costo)) / parseFloat(row.precio_costo) * 100).toFixed(1);
                return (
                    <span className={`text-sm font-medium ${margen > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {margen}%
                    </span>
                );
            }
        },
        {
            header: 'Acciones',
            cell: (row) => (
                <div className="flex items-center gap-2">
                    <button
                        onClick={(e) => { e.stopPropagation(); handleEdit(row); }}
                        className="p-1.5 hover:bg-blue-50 text-blue-600 rounded transition-colors"
                        title="Editar"
                    >
                        <Edit className="w-4 h-4" />
                    </button>
                    <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(row.id); }}
                        className="p-1.5 hover:bg-red-50 text-red-600 rounded transition-colors"
                        title="Eliminar"
                    >
                        <Trash2 className="w-4 h-4" />
                    </button>
                </div>
            )
        }
    ];

    const productosStockBajo = products.filter(p => p.stock_bajo && p.stock > 0).length;
    const productosSinStock = products.filter(p => p.stock === 0).length;
    const valorInventario = products.reduce((sum, p) => sum + (p.stock * parseFloat(p.precio_venta)), 0);

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-gray-900">Inventario</h1>
                    <p className="text-gray-600 mt-1">Gestiona tus productos y stock</p>
                </div>
                <div className="flex gap-3">
                    <Button
                        variant="outline"
                        onClick={() => setShowCategoriaModal(true)}
                    >
                        + Categoría
                    </Button>
                    <Button
                        icon={Plus}
                        onClick={() => {
                            resetForm();
                            setSelectedProduct(null);
                            setShowModal(true);
                        }}
                    >
                        Nuevo Producto
                    </Button>
                </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-blue-50 text-blue-600 rounded-lg">
                            <Package className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Total Productos</p>
                            <h3 className="text-2xl font-bold text-gray-900">{products.length}</h3>
                        </div>
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-green-50 text-green-600 rounded-lg">
                            <TrendingUp className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Valor Inventario</p>
                            <h3 className="text-2xl font-bold text-gray-900">
                                ${valorInventario.toLocaleString('es-MX', { maximumFractionDigits: 0 })}
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-orange-50 text-orange-600 rounded-lg">
                            <TrendingDown className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Stock Bajo</p>
                            <h3 className="text-2xl font-bold text-gray-900">{productosStockBajo}</h3>
                        </div>
                    </div>
                </div>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center gap-3">
                        <div className="p-3 bg-red-50 text-red-600 rounded-lg">
                            <AlertCircle className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Sin Stock</p>
                            <h3 className="text-2xl font-bold text-gray-900">{productosSinStock}</h3>
                        </div>
                    </div>
                </div>
            </div>

            {/* Filtros */}
            <Card>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-2 relative">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <input
                            type="text"
                            placeholder="Buscar por nombre o código..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                    </div>
                    <select
                        value={categoriaFiltro}
                        onChange={(e) => setCategoriaFiltro(e.target.value)}
                        className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="">Todas las categorías</option>
                        {categorias.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                                {cat.nombre}
                            </option>
                        ))}
                    </select>
                    <select
                        value={stockFiltro}
                        onChange={(e) => setStockFiltro(e.target.value)}
                        className="px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                        <option value="todos">Todos los productos</option>
                        <option value="bajo">Stock bajo</option>
                        <option value="sin_stock">Sin stock</option>
                    </select>
                </div>
            </Card>

            {/* Table */}
            <Card>
                <Table columns={columns} data={filteredProducts} />
                {filteredProducts.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                        No se encontraron productos
                    </div>
                )}
            </Card>

            {/* Modal Producto */}
            {showModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
                        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between sticky top-0 bg-white z-10">
                            <h2 className="text-xl font-semibold text-gray-900">
                                {selectedProduct ? 'Editar Producto' : 'Nuevo Producto'}
                            </h2>
                            <button
                                onClick={() => {
                                    setShowModal(false);
                                    setSelectedProduct(null);
                                }}
                                className="text-gray-400 hover:text-gray-600"
                                disabled={submitting}
                            >
                                ✕
                            </button>
                        </div>

                        <form onSubmit={handleSubmit} className="p-6 space-y-4">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Código *
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.codigo}
                                        onChange={(e) => setFormData({ ...formData, codigo: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Nombre *
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.nombre}
                                        onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Descripción
                                </label>
                                <textarea
                                    value={formData.descripcion}
                                    onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                                    rows="2"
                                    disabled={submitting}
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Categoría *
                                </label>
                                <select
                                    value={formData.categoria}
                                    onChange={(e) => setFormData({ ...formData, categoria: e.target.value })}
                                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required
                                    disabled={submitting}
                                >
                                    <option value="">Seleccionar...</option>
                                    {categorias.map((cat) => (
                                        <option key={cat.id} value={cat.id}>
                                            {cat.nombre}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Stock Actual *
                                    </label>
                                    <input
                                        type="number"
                                        value={formData.stock}
                                        onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        min="0"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Stock Mínimo *
                                    </label>
                                    <input
                                        type="number"
                                        value={formData.stock_minimo}
                                        onChange={(e) => setFormData({ ...formData, stock_minimo: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        min="0"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Precio Costo * ($)
                                    </label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        value={formData.precio_costo}
                                        onChange={(e) => setFormData({ ...formData, precio_costo: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        min="0.01"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Precio Venta * ($)
                                    </label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        value={formData.precio_venta}
                                        onChange={(e) => setFormData({ ...formData, precio_venta: e.target.value })}
                                        className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                        min="0.01"
                                        required
                                        disabled={submitting}
                                    />
                                </div>
                            </div>

                            {formData.precio_costo && formData.precio_venta && (
                                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                                    <p className="text-sm text-blue-800">
                                        Margen de ganancia: <span className="font-semibold">
                                            {((parseFloat(formData.precio_venta) - parseFloat(formData.precio_costo)) / parseFloat(formData.precio_costo) * 100).toFixed(1)}%
                                        </span>
                                    </p>
                                </div>
                            )}

                            <div className="flex gap-3 pt-4">
                                <Button type="submit" className="flex-1" disabled={submitting}>
                                    {submitting ? 'Guardando...' : (selectedProduct ? 'Actualizar' : 'Crear')} Producto
                                </Button>
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => {
                                        setShowModal(false);
                                        setSelectedProduct(null);
                                    }}
                                    disabled={submitting}
                                >
                                    Cancelar
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Modal Nueva Categoría */}
            {showCategoriaModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
                        <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                            <h2 className="text-xl font-semibold text-gray-900">
                                Nueva Categoría
                            </h2>
                            <button
                                onClick={() => setShowCategoriaModal(false)}
                                className="text-gray-400 hover:text-gray-600"
                                disabled={submitting}
                            >
                                ✕
                            </button>
                        </div>

                        <form onSubmit={handleCrearCategoria} className="p-6 space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Nombre *
                                </label>
                                <input
                                    type="text"
                                    value={nuevaCategoria.nombre}
                                    onChange={(e) => setNuevaCategoria({ ...nuevaCategoria, nombre: e.target.value })}
                                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    required
                                    disabled={submitting}
                                    autoFocus
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Descripción
                                </label>
                                <textarea
                                    value={nuevaCategoria.descripcion}
                                    onChange={(e) => setNuevaCategoria({ ...nuevaCategoria, descripcion: e.target.value })}
                                    className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                                    rows="3"
                                    disabled={submitting}
                                />
                            </div>

                            <div className="flex gap-3 pt-4">
                                <Button type="submit" className="flex-1" disabled={submitting}>
                                    {submitting ? 'Creando...' : 'Crear Categoría'}
                                </Button>
                                <Button
                                    type="button"
                                    variant="outline"
                                    onClick={() => setShowCategoriaModal(false)}
                                    disabled={submitting}
                                >
                                    Cancelar
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}