export const METODOS_PAGO = [
  { value: 'efectivo', label: 'Efectivo' },
  { value: 'tarjeta', label: 'Tarjeta' },
  { value: 'transferencia', label: 'Transferencia' }
];

export const ROLES_USUARIO = [
  { value: 'admin', label: 'Administrador' },
  { value: 'vendedor', label: 'Vendedor' },
  { value: 'almacen', label: 'Almacén' }
];

export const STATUS_FACTURA = [
  { value: 'borrador', label: 'Borrador' },
  { value: 'timbrada', label: 'Timbrada' },
  { value: 'cancelada', label: 'Cancelada' }
];